package org.example.dto.category;

import lombok.Data;

@Data
public class CategoryUpdateDTO {
    private String name;
    private String description;
    private String image;
}
